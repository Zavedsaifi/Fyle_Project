import json
from flask import request

from flask import Blueprint, jsonify

from .schema import AssignmentSchema, AssignmentSubmitSchema
from .. import decorators
from ... import db
from ...models.assignments import Assignment, AssignmentStateEnum
from ...models.principals import Principal
from ...models.teachers import Teacher

principal_assignment_resources = Blueprint('principal_assignment_resources', __name__)


@principal_assignment_resources.route('/assignments', methods=['GET'], strict_slashes=False)
@decorators.authenticate_principal
def get_assignments(pay):
    if not Principal.is_exist(pay.principal_id):
        return jsonify({"data": {"message": "Not authenticated principal"}})
    assignments = Assignment.get_submitted_assignments()
    result = []
    for assignment in assignments:
        result.append({
            "id": assignment.id,
            "student_id": assignment.student_id,
            "teacher_id": assignment.teacher_id,
            "content": assignment.content,
            "grade": assignment.grade.name if assignment.grade else None,
            "state": assignment.state.name,
            "created_at": assignment.created_at.isoformat(),
            "updated_at": assignment.updated_at.isoformat()
        })

    return jsonify({"data": result})


@principal_assignment_resources.route('/teachers', methods=['GET'], strict_slashes=False)
@decorators.authenticate_principal
def get_all_teachers(pay):
    if not Principal.is_exist(pay.principal_id):
        return jsonify({"data": {"message": "Not authenticated principal"}})
    teacher_list = Teacher.get_all_teachers()
    result = []
    for teacher in teacher_list:
        result.append({
            "id": teacher.id,
            "user_id": teacher.user_id,
            "created_at": teacher.created_at.isoformat(),
            "updated_at": teacher.updated_at.isoformat()
        })

    return jsonify({"data": result})

@principal_assignment_resources.route('/assignments/grade', methods=['POST'], strict_slashes=False)
@decorators.authenticate_principal
def update_grades(pay, *args, **kwargs):
    if not Principal.is_exist(pay.principal_id):
        return jsonify({"data": {"message": "Not authenticated principal"}})

    body = request.json
    assignment_id = body.get('id')
    grade = body.get('grade')

    if not Assignment.is_submitted(assignment_id):
        return jsonify({"data": {"message": "assignment is not submitted yet"}})

    assignment = Assignment.mark_grade(assignment_id, grade, pay)
    db.session.commit()
    result = {
        "id": assignment.id,
        "created_at": assignment.created_at.isoformat(),
        "updated_at":  assignment.updated_at.isoformat(),
        "content": assignment.content,
        "grade": assignment.grade,
        "state": assignment.state,
        "student_id": assignment.student_id,
        "teacher_id": assignment.teacher_id,
    }

    return jsonify({"data": result})
