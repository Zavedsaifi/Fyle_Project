from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from sqlalchemy import event
from sqlalchemy.engine import Engine
from sqlite3 import Connection as SQLite3Connection
from flask import Flask, request, jsonify
from flask_mysqldb import MySQL

# from core.server import run_url

mysql = MySQL()
db = SQLAlchemy()
migrate = Migrate()


def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Zaved%40123@localhost/Fyle'
    app.config['SQLALCHEMY_ECHO'] = False
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['DEBUG'] = True
    from core.apis.assignments import student_assignments_resources, teacher_assignments_resources, principal_assignment_resources
    app.register_blueprint(student_assignments_resources, url_prefix='/student')
    app.register_blueprint(teacher_assignments_resources, url_prefix='/teacher')
    app.register_blueprint(principal_assignment_resources, url_prefix='/principal')

    db.init_app(app)
    app.test_client()
    return app


# this is to enforce fk (not done by default in sqlite3)
@event.listens_for(Engine, "connect")
def _set_sqlite_pragma(dbapi_connection, connection_record):
    if isinstance(dbapi_connection, SQLite3Connection):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON;")
        cursor.close()
